# Lab 3: Uninformed Search (BFS, DFS, DLS & UCS)
# Name: Ali Abbas | Roll No: 031 | Section: BSSE-4A
# Submitted to: Sir Rasikh Ali

from collections import deque
import heapq

# --- Part 1: Original Graph & Modified BFS / DFS from PDF (Section 3.2 & Task 1) ---
graph = {
    "A": ["B", "C"],
    "B": ["D", "E"],
    "C": ["F"],
    "D": [],
    "E": ["G"],
    "F": [],
    "G": []
}

def bfs(start, goal, g=graph):
    q = deque([(start, [start])])
    seen = {start}
    visit_order = []
    while q:
        node, path = q.popleft()
        visit_order.append(node)
        if node == goal:
            return path, visit_order
        for n in g[node]:
            if n not in seen:
                seen.add(n)
                q.append((n, path + [n]))
    return None, visit_order

def dfs(start, goal, g=graph):
    stack = [(start, [start])]
    seen = set()
    visit_order = []
    while stack:
        node, path = stack.pop()
        if node in seen:
            continue
        seen.add(node)
        visit_order.append(node)
        if node == goal:
            return path, visit_order
        for n in reversed(g[node]):
            stack.append((n, path + [n]))
    return None, visit_order

print("--- Task 1: BFS and DFS on Original Graph (A to G) ---")
bfs_path, bfs_order = bfs("A", "G")
dfs_path, dfs_order = dfs("A", "G")
print(f"BFS Path: {bfs_path} | Visit Order: {bfs_order}")
print(f"DFS Path: {dfs_path} | Visit Order: {dfs_order}")


# --- Part 2: Lab Task 2 - Depth-Limited Search (DLS Only) ---
# Root A is at depth 0. Uses path-local cycle check and returns FOUND, CUTOFF, or FAILURE.
def dls(start, goal, limit, g=graph):
    def recursive_dls(node, path, depth):
        if node == goal:
            return "FOUND", path
        if depth == limit:
            # If the node still has unvisited neighbours, it is a CUTOFF
            has_unexplored = any(n not in path for n in g[node])
            return ("CUTOFF" if has_unexplored else "FAILURE"), None

        cutoff_occurred = False
        for n in g[node]:
            if n not in path:  # Path-local cycle check
                status, result_path = recursive_dls(n, path + [n], depth + 1)
                if status == "FOUND":
                    return "FOUND", result_path
                elif status == "CUTOFF":
                    cutoff_occurred = True

        return ("CUTOFF", None) if cutoff_occurred else ("FAILURE", None)

    return recursive_dls(start, [start], 0)

print("\n--- Task 2: Depth-Limited Search (DLS) for Limits 1, 2, 3, and 4 ---")
for lim in [1, 2, 3, 4]:
    status, path = dls("A", "G", lim)
    print(f"Depth Limit {lim} -> Status: {status:<7} | Path: {path}")

# Edge Case Test for DLS (Unreachable Goal to show FAILURE vs CUTOFF)
fail_status, fail_path = dls("A", "Z", 4)
print(f"Edge Case (Unreachable Goal 'Z' at Limit 4) -> Status: {fail_status} | Path: {fail_path}")


# --- Part 3: Lab Task 3 - Weighted Graph & Uniform Cost Search (UCS) ---
# Original edges kept + alternative corridor C -> G added (Section 3.7)
weighted_graph = {
    "A": [("B", 1), ("C", 2)],
    "B": [("D", 2), ("E", 1)],
    "C": [("F", 3), ("G", 10)],  # Added corridor C -> G with weight 10
    "D": [],
    "E": [("G", 1)],
    "F": [],
    "G": []
}

# Unweighted adjacency view of the same extended graph for BFS comparison
extended_unweighted = {u: [v for v, w in nbrs] for u, nbrs in weighted_graph.items()}

def ucs(start, goal, wg=weighted_graph):
    # Priority queue stores (cost, path_list)
    pq = [(0, start, [start])]
    best_cost = {}
    visit_order = []
    while pq:
        cost, node, path = heapq.heappop(pq)
        if node in best_cost and best_cost[node] <= cost:
            continue
        best_cost[node] = cost
        visit_order.append((node, cost))
        if node == goal:
            return path, cost, visit_order
        for nbr, weight in wg[node]:
            new_cost = cost + weight
            if nbr not in best_cost or new_cost < best_cost.get(nbr, float("inf")):
                heapq.heappush(pq, (new_cost, nbr, path + [nbr]))
    return None, float("inf"), visit_order

def sum_path_cost(path, wg=weighted_graph):
    total = 0
    for i in range(len(path) - 1):
        u, v = path[i], path[i + 1]
        for nbr, w in wg[u]:
            if nbr == v:
                total += w
                break
    return total

print("\n--- Task 3: UCS vs. BFS on Extended Weighted Graph ---")
ucs_path, ucs_cost, ucs_order = ucs("A", "G")
bfs_ext_path, bfs_ext_order = bfs("A", "G", extended_unweighted)
bfs_ext_cost = sum_path_cost(bfs_ext_path)

print(f"UCS Returned Path : {ucs_path} (Hops: {len(ucs_path)-1})")
print(f"UCS Total Cost    : {ucs_cost} (Independently Verified Sum: {sum_path_cost(ucs_path)})")
print(f"UCS Process Order : {ucs_order}")
print(f"BFS Returned Path : {bfs_ext_path} (Hops: {len(bfs_ext_path)-1}, Total Cost on Weighted Graph: {bfs_ext_cost})")
