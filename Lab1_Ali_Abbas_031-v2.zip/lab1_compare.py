# Lab 1: Introduction to AI & Paradigms
# Name: Ali Abbas | Roll No: 031 | Section: BSSE-4A
# Submitted to: Sir Rasikh Ali
# Note: All thresholds (score >= 70, attendance >= 75, probability >= 0.70)
# are synthetic lab assumptions. "Review" is just a flag for a human reviewer.

# --- Part 1: Original Code from Lab Manual (Section 1.5) ---
def symbolic(score, complete):
    return "Review" if complete and score >= 70 else "Hold"

def threshold(probability):
    return "Review" if probability >= 0.70 else "Hold"

cases = [
    ("complete_high", 82, True, 0.81),
    ("complete_low", 68, True, 0.74),
    ("incomplete_high", 91, False, 0.88),
    ("boundary", 70, True, 0.70)
]

print("--- Original Comparison (Section 1.5) ---")
print("case | symbolic | threshold | disagreement")
for name, score, complete, probability in cases:
    a, b = symbolic(score, complete), threshold(probability)
    print(name, a, b, a != b, sep=" | ")


# --- Part 2: Lab Task 2 (Modified Rule-Based System with 2 New Conditions) ---
# Kept: score >= 70 and complete == True
# Added Condition 1: attendance >= 75
# Added Condition 2: disciplinary_clear == True

def modified_rule_based(score, complete, attendance, disciplinary_clear):
    if complete and score >= 70 and attendance >= 75 and disciplinary_clear:
        return "Review"
    else:
        return "Hold"

# 4 Core Test Cases:
# 1. Pass case
# 2. Failure of new condition 1 (attendance < 75)
# 3. Failure of new condition 2 (disciplinary_clear == False)
# 4. Threshold boundary case (score == 70 and attendance == 75)
test_cases = [
    ("Case 1 (Pass All)", 80, True, 85, True, "Review", "All conditions are met."),
    ("Case 2 (Fail Attendance)", 80, True, 65, True, "Hold", "Failed because attendance (65) is below 75."),
    ("Case 3 (Fail Discipline)", 80, True, 85, False, "Hold", "Failed because disciplinary_clear is False."),
    ("Case 4 (Boundary Test)", 70, True, 75, True, "Review", "Passed right on the exact boundary (score=70, attendance=75).")
]

print("\n--- Lab Task 2: Modified Rule-Based Test Cases ---")
for name, score, complete, attendance, disc, expected, reason in test_cases:
    actual = modified_rule_based(score, complete, attendance, disc)
    print(f"{name}:")
    print(f"  Input    : score={score}, complete={complete}, attendance={attendance}, disciplinary_clear={disc}")
    print(f"  Expected : {expected} | Actual: {actual}")
    print(f"  Reason   : {reason}")
