# Lab 2: Intelligent Agents & the PEAS Framework
# Name: Ali Abbas | Roll No: 031 | Section: BSSE-4A
# Submitted to: Sir Rasikh Ali
# Note: Temperature is in Celsius and occupied is a Boolean.
# ECO, COOL, WARM, and IDLE are simulated labels (no real hardware is controlled).

# --- Part 1: Original Reflex Agent from Lab Manual (Section 2.5) ---
class ClassroomAgent:
    def act(self, temp, occupied):
        if not occupied:
            return "ECO"
        if temp > 26:
            return "COOL"
        if temp < 20:
            return "WARM"
        return "IDLE"

agent = ClassroomAgent()
percepts = [
    (29, True),
    (29, True),
    (20, True),
    (26, True),
    (19, True),
    (29, False)
]

print("--- Part 1: Original Reflex Agent Trace (Section 2.5) ---")
for step, percept in enumerate(percepts, 1):
    print(step, percept, "target mode", agent.act(*percept))


# --- Part 2: Lab Task 3 - Stateful Agent (Remembers Previous Mode) ---
class StatefulClassroomAgent:
    def __init__(self):
        self.prev_mode = None

    def get_target_mode(self, temp, occupied):
        # Keep existing occupancy priority and temperature thresholds
        if not occupied:
            return "ECO"
        if temp > 26:
            return "COOL"
        if temp < 20:
            return "WARM"
        return "IDLE"

    def act(self, temp, occupied):
        previous = self.prev_mode
        target = self.get_target_mode(temp, occupied)
        # Only send a command if the target mode is different from the previous mode
        send_command = (target != previous)
        outcome = "SEND_COMMAND" if send_command else "NO_COMMAND (Repeated)"
        self.prev_mode = target
        return previous, target, send_command, outcome

stateful_agent = StatefulClassroomAgent()

print("\n--- Part 2: Lab Task 3 - Stateful Agent Trace ---")
print("Step | Prev Mode | Percept (Temp, Occ) | Target Mode | Command Outcome")
for step, percept in enumerate(percepts, 1):
    prev_m, target_m, send_cmd, outcome = stateful_agent.act(*percept)
    print(f"{step:<4} | {str(prev_m):<9} | {str(percept):<19} | {target_m:<11} | {outcome}")


# --- Part 3: Edge Case Test - Noisy Sequence Around 26 C (Section 2.7) ---
noisy_agent = StatefulClassroomAgent()
noisy_percepts = [(27, True), (26, True), (27, True), (26, True)]

print("\n--- Part 3: Edge Case - Noisy Fluctuation Around 26 C ---")
for step, percept in enumerate(noisy_percepts, 1):
    prev_m, target_m, send_cmd, outcome = noisy_agent.act(*percept)
    print(f"Step {step}: Percept={percept} | Prev={prev_m} -> Target={target_m} | {outcome}")
